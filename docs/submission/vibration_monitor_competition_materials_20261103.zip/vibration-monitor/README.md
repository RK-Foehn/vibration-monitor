# 基于 Zynq 的旋转机械振动状态监测系统

系统使用领航者 XC7Z020CLG400-2 和 LIS3DH，PL 完成 SPI 采集、FIFO 与 16 点 X 轴窗口特征，ARM 裸机程序经 AXI4-Lite 读取结果并通过 UART0 输出，Python 显示 Peak、原始窗口 RMS、趋势并保存 CSV。

实验对象为 370 电机，包含正常运行对照与转轴受控扰动两组实验，两组均通过手动 PWM 调速器从低速逐步调到高速。当前未接转速计，不填写实测 RPM；原始 RMS 含重力和直流分量。功能说明不包含故障电机分类或故障识别准确率。

## 目录对照

| 指南分类 | 本包位置 |
|---|---|
| 设计源码 | fpga/rtl、software/ps_uart_app、software/pc_monitor |
| 仿真与验证 | fpga/sim、sim/results |
| 构建脚本 | software/ps_uart_app/build.py、fpga/scripts |
| 综合与实现报告 | fpga/vivado/zynq_vibration_system/zynq_vibration_system.runs |
| 上板文件与实测记录 | board、data/board、data/motor_comparison |
| 可复用技能包 | skill |
| 中英文海报 | posters |
| 模型协作摘录 | report/ai_collaboration.md |

最终技术报告和演示视频由团队统一提交。data/board 为采集与通信验证资料；data/motor_comparison 为正常对照与转轴受控扰动的原始 CSV、事件记录、采集摘要、对比截图及统计说明。

## 环境与复现

采用 Vivado/Vitis 2023.2，与项目开发和验证环境一致。PS 为 ps7_cortexa9_0 standalone，UART0 为 115200、8N1、无流控，AXI 基址 0x40000000。

1. 保持目录层级，打开 fpga/vivado/zynq_vibration_system/zynq_vibration_system.xpr。当前 BD 和约束位于工程 .srcs 目录；Vivado 可从 BD 重新生成 IP 输出产品。所需顶层 wrapper 已保留。
2. 使用 Vitis 2023.2 的 vitis.bat 执行 `vitis.bat -s software/ps_uart_app/build.py <新的工作区绝对路径>`。构建脚本从本包 UART0 XSA 建立平台并导入应用源码。
3. 既有上板文件位于 board/elf、board/bitstream、board/psinit。运行步骤见 board/README.md。
4. 按 software/pc_monitor/README.md 安装依赖，从该目录启动上位机。连接前关闭其它占用同一串口的程序。
5. 静态检查：`python skill/scripts/audit_handoff.py .`。校验脚本用于检查文件依赖和 XSA 配置。

保留 README.md、SKILL.md 及 CMakeLists.txt、UserConfig.cmake、Empty_applicationExample.cmake 等工具约定名称；自编资料使用英文文件名。源文件中的第三方版权声明保持原样。

## 电机实验结果

正常对照组 105 个窗口、受控扰动组 47 个窗口。Peak 中位数分别为 66 和 606 counts，原始 RMS 中位数分别为 35.59 和 464.67 counts。详细工况、数据来源及统计解释见 data/motor_comparison/README.md。

## 目录与材料约定

依据选题指南 3.3.5.4 的非强制推荐目录，本工程将 RTL 放在 fpga/rtl，PS 与上位机程序放在 software，目录对照见上表。skill/README.md 说明技能包的使用方法。report/ai_collaboration.md 保存模型协作记录摘录，正式报告应结合该记录介绍协作与技能提炼过程。英文海报遵循 AMD 模板，不含队伍身份信息。
